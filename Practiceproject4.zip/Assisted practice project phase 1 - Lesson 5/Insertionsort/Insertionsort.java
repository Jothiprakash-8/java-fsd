package pa6;

public class Insertionsort {
	 public static void insertionSort(int a[]) {  
	        int n = a.length;  
	        for (int j = 1; j < n; j++) {  
	            int key = a[j];  
	            int i = j-1;  
	            while ( (i > -1) && ( a [i] > key ) ) {  
	                a [i+1] = a [i];  
	                i--;  
	            }  
	            a[i+1] = key;  
	        }  
	    }  

	public static void main(String[] args) {
		 int[] a1 = {14,75,24,84,39,71,98};    
	     System.out.println("Before Insertion Sort");    
	     for(int i:a1){    
	            System.out.print(i+" ");    
	        }    
	        System.out.println();    
	        insertionSort(a1);   
	        System.out.println("After Insertion Sort");    
	        for(int i:a1){    
	            System.out.print(i+" ");    
	        }    
		}

}
