package pa2;

public class Binarysearch {

	public static void main(String[] args) {
		int[] a= {17,23,35,47,58,65};
        int key = 47;
        int length = a.length;
        binarySearch(a,0,key,length);
    }

  public static void binarySearch(int[] a, int start, int key, int length){

        int midValue = (start+length)/2;
        while(start<=length){

            if(a[midValue]<key){

                start = midValue + 1;
            } 
            else if(a[midValue]==key)
            {
                System.out.println("Element is found at index :"+midValue);
                break;
            }
            else 
            {

                length=midValue-1;
            }
            midValue = (start+length)/2;
        }
            if(start>length){

                System.out.println("Element is not found");
            }
   }

}
