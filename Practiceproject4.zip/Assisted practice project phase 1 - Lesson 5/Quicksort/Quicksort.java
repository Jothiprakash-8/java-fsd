package pa8;

public class Quicksort {
	int partitionfunc(int a[], int start, int end)  
	{  
	    int pivot = a[end];
	    int i = (start - 1);  
	  
	    for (int j = start; j <= end - 1; j++)  
	    {   
	        if (a[j] < pivot)  
	        {  
	            i++; 
	            int t = a[i];  
	            a[i] = a[j];  
	            a[j] = t;  
	        }  
	    }  
	    int t = a[i+1];  
	    a[i+1] = a[end];  
	    a[end] = t;  
	    return (i + 1);  
	}  
	  
	void quicks(int a[], int start, int end)  
	{  
	    if (start < end)  
	    {  
	        int p = partitionfunc(a, start, end);  
	        quicks(a, start, p - 1);  
	        quicks(a, p + 1, end);  
	    }  
	}  
	void display(int a[], int n)  
	{  
	    int i;  
	    for (i = 0; i < n; i++)  
	        System.out.print(a[i] + " ");  
	}  

	public static void main(String[] args) {
		int a[] = {19,28,11,15,33,75,89,96,46};  
	    int n = a.length;  
	    System.out.println("\nBefore sorting array elements are - ");  
	    Quicksort q1 = new Quicksort();  
	    q1.display(a, n);  
	    q1.quicks(a, 0, n - 1);  
	    System.out.println("\nAfter sorting array elements are - ");  
	    q1.display(a, n);  
	    System.out.println();
		}

}
