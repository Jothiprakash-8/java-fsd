package pa1;
import java.util.Scanner;

public class Linearsearch {

	public static void main(String[] args) {
		int[] a= {76,85,23,47,12,90};

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the element to be searched in an array");
        int s = sc.nextInt();
        int result = (int)linear(a,s);
        if(result==-1){

               System.out.println("Element not present in the array");
            } 
        else {

                System.out.println("Element found at "+result+" and the search element is "+a[result]);
            }


        }
public static int linear(int a[], int b) {

    int length = a.length;
    for (int i = 0; i < length - 1; i++) {

    if (a[i] == b) {

            return i;

         }
     }

            return -1;
}

}
