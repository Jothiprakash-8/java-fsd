package pj8;
import java.util.Stack;

public class Stackpgm {
	static final int b = 1000; 
	int top; 
	int a[] = new int[b];  
	boolean isEmpty() 
	{ 
    		return (top < 0); 
	} 
	Stackpgm() 
	{ 
    		top = -1; 
	} 
	boolean push(int x) 
	{ 
    		if (top >= (b-1)) 
    		{ 
        			System.out.println("Stack Overflow"); 
        			return false; 
    		} 
    		else
    		{ 
        			a[++top] = x; 
        			System.out.println(x + " pushed into stack"); 
        			return true; 
    		} 
	} 
int pop() 
	{ 
    		if (top < 0) 
    		{ 
        			System.out.println("Stack Underflow"); 
        			return 0; 
    		} 
    		else
    		{ 
        			int x = a[top--]; 
        			return x; 
    		} 
	} 

	public static void main(String[] args) {
		Stackpgm s= new Stackpgm();
	    s.push(1);
	    s.push(20);
	    s.push(50);
	    System.out.println(s.pop());

	}

}
