package pj6;

public class Circularlinkedlist {
	static class Node 
	{ 
		int data; 
    		Node next; 
            	Node(int d) 
    		{ 
        			data = d; 
        			next = null; 
    		} 
}
    Node head; 
    Circularlinkedlist()   
    { 
    head = null; 
     } 
	void sortedInsertinto(Node newnodenow) 
	{ 
    		Node current = head; 
   if (current == null) 
    		{ 
        			newnodenow.next = newnodenow; 
        			head = newnodenow; 
		} 
      else if (current.data >= newnodenow.data) 
    		{ 
    	  while (current.next != head)
              current = current.next;

          current.next = newnodenow;
          newnodenow.next = head;
          head = newnodenow;
    		} 
    		else
    		{
           while (current.next != head && current.next.data < newnodenow.data) 
            			current = current.next; 
			newnodenow.next = current.next; 
        			current.next = newnodenow; 
    		} 
}
          void display() 
	{ 
    		if (head != null) 
   		{ 
        			Node temp = head; 
        			do
       			{ 
            			System.out.print(temp.data + " "); 
            			temp = temp.next; 
        			}  while (temp != head); 
    		} 
	}


	public static void main(String[] args) {
		Circularlinkedlist list = new Circularlinkedlist(); 
		int x[] = new int[] {25,73,47,81,39,44,94}; 
		Node a = null; 
		for (int i = 0; i <7; i++) 
		{ 
   			a = new Node(x[i]); 
    			list.sortedInsertinto(a); 
		} 
list.display(); 

		

	}

}
