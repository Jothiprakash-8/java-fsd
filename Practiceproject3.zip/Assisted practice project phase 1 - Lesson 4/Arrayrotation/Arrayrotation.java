package pj1;
import java.util.Arrays;

public class Arrayrotation {
	public static void rightRotateByOne(int[] x)
    {
        int last = x[x.length - 1];
        for (int i = x.length - 2; i >= 0; i--) {
            x[i + 1] = x[i];
        }
 
        x[0] = last;
    }
 
  
    public static void rightRotate(int[] x, int y)
    {
        
        if (y < 0 || y >= x.length) {
            return;
        }
 
        for (int i = 0; i < y; i++) {
            rightRotateByOne(x);
        }
    }

	public static void main(String[] args) {
		int[] x = { 9,8,7,6,5,4,3 };
        int y = 5;
 
        rightRotate(x, y);
 
        System.out.println(Arrays.toString(x));
		

	}

}
