package pj4;

public class Matrixmultiplication {

	public static void main(String[] args) {
		int r1 = 2, c1 = 3;
		int r2 = 3, c2 = 2;
		int[][] fm = { {1,2,3}, {4,5,6} };
		int[][] sm = { {9,8}, {7,6}, {5,4} };
        int[][] p = multiplication(fm, sm, r1, c1, c2);
        display(p);
}

public static int[][] multiplication(int[][] fm, int[][] sm, int r1, int c1, int c2) 
{
		int[][] p= new int[r1][c2];
		for(int i = 0; i < r1; i++) 
{
    			for (int j = 0; j < c2; j++) 
{
        			for (int k = 0; k < c1; k++) 
{
            				p[i][j] += fm[i][k] * sm[k][j];
        			}
    			}
	 	}
 return p;
}
public static void display(int[][] product) 
{
		System.out.println("Product of two matrices is: ");
		for(int[] row : product) 
{
    			for (int column : row) 
{
        			System.out.print(column + "    ");
    			}
    			System.out.println();
		}


	}

}
