package pj2;

public class Kthsmallest {
	public void sortArr(int arr[])  
	{  
	int size = arr.length;  
	  
	for(int i = 0; i < size; i++)  
	{  
	int temp = i;  
	for(int j = i + 1; j < size; j++)  
	{  
	if(arr[temp] > arr[j])  
	{  
	temp = j;  
	}  
	  
}  
	if(temp != i)  
	{  
	int t = arr[i];  
	arr[i] = arr[temp];  
	arr[temp] = t;   
	}  
	} 
	}  
	  
	public int findKthSmallest(int arr[], int k)  
	{  
	sortArr(arr);   
	return arr[k - 1];  
	}  

	public static void main(String[] args) {
		Kthsmallest o=new Kthsmallest();
		int arr1[] = {22,35,64,14,97,31,78,83,28};  
		  
		int size = arr1.length;  
		int k = 4;  
		int a= o.findKthSmallest(arr1, k);    
		System.out.println("The " + k + "th smallest element of the array is: " + a);  
		
	}

}
