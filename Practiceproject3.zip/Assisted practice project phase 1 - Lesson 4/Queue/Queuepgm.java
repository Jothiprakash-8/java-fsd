package pj9;
import java.util.LinkedList;
import java.util.Queue;
public class Queuepgm {

	public static void main(String[] args) {
		Queue<String> q = new LinkedList<>();
		q.add("Pune");
		q.add("Hyderabad");
		q.add("Bangalore");
		q.add("Chennai");
		q.add("Mumbai");
		System.out.println("Queue is : " +q);
		System.out.println(q.peek());
		q.remove();
		System.out.println("After removing Head of Queue : " +q);

	}

}
