package pj3;

public class Sumofn {
	static int k = 16;
    static int N = 100000; 
    static long a[][] = new long[N][k + 1]; 
    static void func(int arr[], int length) 
    { 
        for (int i = 0; i < length; i++) 
            a[i][0] = arr[i]; 
        for (int j = 1; j <= k; j++) 
            for (int i = 0; i <= length - (1 << j); i++) 
                a[i][j] = a[i][j - 1] + a[i + (1 << (j - 1))][j - 1]; 
    } 
    static long display(int x, int y) 
    {
        long b = 0; 
        for (int j = k; j >= 0; j--)  
        { 
            if (x + (1 << j) - 1 <= y)  
            { 
                b = b + a[x][j];
                x += 1 << j; 
            } 
        } 
        return b; 
    }


	public static void main(String[] args) {
		int i[] = { 3, 7, 2, 5, 8, 9 }; 
        int j = i.length; 
        func(i, j); 
        System.out.println(display(0,3)); 
        System.out.println(display(3, 5)); 
     }

}
