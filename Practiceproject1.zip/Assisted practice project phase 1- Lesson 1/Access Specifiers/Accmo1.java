package pg2;

public class Accmo1 {

	public static void main(String[] args) {
		System.out.println("Dafault Access Specifier");
		Accmo a = new Accmo(); 		  
        a.display(); 


	}

}
