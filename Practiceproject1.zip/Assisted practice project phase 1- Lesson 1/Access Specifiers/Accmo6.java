package pg3;

public class Accmo6 {
	public void display() 
    { 
        System.out.println("We are using Public Access Specifiers"); 
    } 


}
