package pg2;

public class Accmo4 {
	protected void display() 
    { 
        System.out.println("We are using protected access specifier"); 
    } 
}



