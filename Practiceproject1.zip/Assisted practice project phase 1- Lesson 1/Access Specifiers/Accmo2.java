package pg2;

class Accmo2 {
	private void display()
	{
		System.out.println("We are using private access specifier");
	}

}
