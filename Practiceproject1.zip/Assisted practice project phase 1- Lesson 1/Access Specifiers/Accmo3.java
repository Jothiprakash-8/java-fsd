package pg2;

public class Accmo3 {

	public static void main(String[] args) {
		System.out.println("Private Access Specifier");
		Accmo2  b = new Accmo2(); 
		b.display();


	}

}
