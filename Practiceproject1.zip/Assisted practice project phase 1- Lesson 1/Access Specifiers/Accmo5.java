package pg3;
import pg2.*;
public class Accmo5 extends Accmo4 {

	public static void main(String[] args) {

			Accmo5 c = new Accmo5();   
		       c.display();  


	}

}
