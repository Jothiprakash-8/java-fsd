package pg2;

public class Accmo {
	  void display() 
	     { 
	         System.out.println("We are using defalut access specifier"); 
	     } 
	} 




