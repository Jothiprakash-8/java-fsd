package pg4;
import pg3.*;

public class Accmo7 {

	public static void main(String[] args) {
		Accmo6 d = new Accmo6(); 
        d.display();  


	}

}
