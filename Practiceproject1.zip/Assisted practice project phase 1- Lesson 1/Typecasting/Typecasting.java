package pg1;

public class Typecasting {

	public static void main(String[] args) {
		
		System.out.println("Implicit Type Casting");
		char a='J';
		System.out.println("Value of a: "+a);
		
		int w=a;
		System.out.println("Value of w: "+w);
		
		float x=a;
		System.out.println("Value of x: "+x);
		
		long y=a;
		System.out.println("Value of y: "+y);
		
		double z=a;
		System.out.println("Value of z: "+z);
		
				
		System.out.println("\n");
		
		System.out.println("Explicit Type Casting");
		
		
		double b=70.5;
		int c=(int)b;
		System.out.println("Value of b: "+b);
		System.out.println("Value of c: "+c);
		
	}
}


	


