package pg11;
import java.util.regex.*;

public class Reguexp {

	public static void main(String[] args) {
		String pattern = "[a-z]+";
		String check = "HellO Good Morning";
		Pattern p = Pattern.compile(pattern);
		Matcher m= p.matcher(check);
		
		while (m.find())
	      	System.out.println( check.substring( m.start(), m.end() ) );


	}

}
