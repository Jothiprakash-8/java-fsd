package pg9;

public class Stringss {

	public static void main(String[] args) {
        System.out.println("Methods of Strings");
		
		String s=new String("Hello World");
		System.out.println(s.length());

		//substring
		String s1=new String("Good Morning");
		System.out.println(s1.substring(2));

		//String Comparison
		String s2="Hello";
		String s3="Heddo";
		System.out.println(s2.compareTo(s3));

		//IsEmpty
		String s4="";
		System.out.println(s4.isEmpty());

		//toLowerCase
		String s5="Hai";
		System.out.println(s5.toLowerCase());
		
		//replace
		String s6="Heldo";
		String replace=s6.replace('d', 'l');
		System.out.println(replace);

		//equals
		String a="Welcome to Java Programming";
		String b="WeLcOmE tO JaVa pRogramming";
		System.out.println(a.equals(b));
 
		System.out.println("\n");
		System.out.println("Creating StringBuffer");
		//Creating StringBuffer and append method
		StringBuffer sb=new StringBuffer("Welcome to Java");
		sb.append("Enjoy your learning students");
		System.out.println(sb);

		//insert method
		sb.insert(0, 'w');
		System.out.println(s);

		//replace method
		StringBuffer sb1=new StringBuffer("Hello");
		sb1.replace(0, 2, "hEl");
		System.out.println(sb1);

		//delete method
		sb1.delete(0, 1);
		System.out.println(sb1);
		
		//StringBuilder
		System.out.println("\n");
		System.out.println("Creating StringBuilder");
		StringBuilder sb2=new StringBuilder("Happy");
		sb2.append("Learning");
		System.out.println(sb2);

		System.out.println(sb2.delete(0, 1));

		System.out.println(sb2.insert(1, "Welcome"));

		System.out.println(sb2.reverse());
				
		//conversion	
		System.out.println("\n");
		System.out.println("Conversion of Strings to StringBuffer and StringBuilder");
		
		String str = "Hello"; 
        
        // conversion from String object to StringBuffer 
        StringBuffer sbr = new StringBuffer(str); 
        sbr.reverse(); 
        System.out.println("String to StringBuffer");
        System.out.println(sbr); 
          
        // conversion from String object to StringBuilder 
        StringBuilder sbl = new StringBuilder(str); 
        sbl.append("world"); 
        System.out.println("String to StringBuilder");
        System.out.println(sbl);              


	}

}
