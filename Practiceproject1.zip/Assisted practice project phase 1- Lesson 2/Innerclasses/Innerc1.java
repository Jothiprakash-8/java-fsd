package pg8;

public class Innerc1 {
	private String msg="Hello";

	 void display(){  
		 class Inner{  
			 void msg(){
				 System.out.println(msg);
			 }  
	  }  
	  
	  Inner l=new Inner();  
	  l.msg();  
	 }

	public static void main(String[] args) {
		Innerc1  a=new Innerc1 ();  
		a.display();  

		

	}

}
