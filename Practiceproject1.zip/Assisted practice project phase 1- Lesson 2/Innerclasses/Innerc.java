package pg8;

public class Innerc {
	private String msg="Welcome to Java Program "; 
	 
	 class Inner{  
	  void hello()
	  {
		  System.out.println(msg+", Let us know about Inner Classes");
		  }  
	 }  


	public static void main(String[] args) {

		Innerc I=new Innerc();
		Innerc.Inner in=I.new Inner();  
		in.hello();  
	}
}



