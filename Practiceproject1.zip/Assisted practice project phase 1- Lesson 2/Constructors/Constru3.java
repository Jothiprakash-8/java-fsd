package pg5;

public class Constru3 {

	public static void main(String[] args) {
		Constru2 c=new Constru2(1,"Ram charan");
		Constru2 c1=new Constru2(2,"Chiru");
		c.display();
		c1.display();


	}

}
