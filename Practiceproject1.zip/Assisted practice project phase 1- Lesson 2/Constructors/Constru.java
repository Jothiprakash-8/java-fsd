package pg5;

public class Constru {
	int a;
	String b;

void display() {
	System.out.println(a+" "+b);
	}

}
