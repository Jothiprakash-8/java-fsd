package pg5;

public class Constru1 {

	public static void main(String[] args) {
		Constru c=new Constru();
		Constru c1=new Constru();
		c.display();
		c1.display();

	}

}
