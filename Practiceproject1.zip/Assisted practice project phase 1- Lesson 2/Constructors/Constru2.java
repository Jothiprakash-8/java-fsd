package pg5;

public class Constru2 {
	int id;
	String name;

	Constru2(int i,String n)
	{
	id=i;
	name=n;
	}

	void display() {
	System.out.println(id+" "+name);
	}


}
