package pg3;

public class Methodpgm {
	public int addnumbers(int a,int b) {
		int c=a+b;
		return c;
	}


	public static void main(String[] args) {
		Methodpgm m=new Methodpgm();
		int d=m.addnumbers(20,5);
		System.out.println(d);

		
		
		

	}

}
