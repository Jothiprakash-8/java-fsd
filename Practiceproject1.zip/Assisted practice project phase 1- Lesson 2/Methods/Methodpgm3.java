package pg3;

public class Methodpgm3 {
	public void area(int breadth,int height)
    {
         System.out.println("Area of Triangle : "+(0.5*breadth*height));
    }
    public void area(int radius) 
    {
         System.out.println("Area of Circle : "+(3.14*radius*radius));
    }


	public static void main(String[] args) {
		Methodpgm3 m=new Methodpgm3();
	       m.area(10,12);
	       m.area(5);  


	}

}
