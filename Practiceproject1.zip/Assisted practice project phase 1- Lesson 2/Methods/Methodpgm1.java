package pg3;

public class Methodpgm1 {
	int a=250;

	int operation(int val) {
		a =a*10/100;
		return(a);
	}


	public static void main(String[] args) {
		Methodpgm1 m = new Methodpgm1();
		System.out.println("Before operation value of a is "+m.a);
		m.operation(100);
		System.out.println("After operation value of a is "+m.a);

		

	}

}
